========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 07.12.2022
========================================================================

* Zawartosc:
============

Katalog NUM6 zawiera:
--------------------------------------------------------------------

I.     Program obliczający wartości własne za pomocą algorytmu QR,
        największą co do modułu wartość i odpowiadający jej wektor 
        własny za pomocą metody potęgowej.

       Program sklada sie z 1 pliku w jezyku python
            1) Num6.py - program glowny
            2) raport.pdf
            3) A.txt, B.txt - pliki tekstowe z macierzami
           
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 num6.py
  

========================================================================


