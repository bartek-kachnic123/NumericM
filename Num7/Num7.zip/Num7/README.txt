========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 21.12.2022
========================================================================

* Zawartosc:
============

Katalog NUM7 zawiera:
--------------------------------------------------------------------

I.     Program wyznacza przybliżone wartości między węzłami 
        za pomocą interpolacji wielomianowej Lagrange'a.

       Program sklada sie z 1 pliku w jezyku python
            1) Num7.py - program glowny
            2) raport.pdf
           
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 Num7.py
  Wybierz funkcję wpisująć 1 lub 2.

========================================================================


