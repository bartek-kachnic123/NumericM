========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 19.01.2023
========================================================================

* Zawartosc:
============

Katalog NUM9 zawiera:
--------------------------------------------------------------------

I.     Program oblicza x* , dla którego wybrana funkcja F(x) = 0.
    Za pomocą 4 metod: bisekcji, falsi, siecznych i Newtona. Wyniki
    zapisuje w plikach *.csv

       Program sklada sie z 1 pliku w jezyku python
            1) Num9.py - program glowny
            2) raport.pdf
            3) *.csv - plik z wynikami
           
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 Num9.py

========================================================================


