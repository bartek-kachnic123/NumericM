========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 04.01.2023
========================================================================

* Zawartosc:
============

Katalog NUM7 zawiera:
--------------------------------------------------------------------

I.     Program oblicza najbardziej pasujące współczynniki dla funkcji F(x)
    dla podanych danych w data.txt, a także generuje własne dane dla 
    funkcji G(x) i oblicza współczynniki z losową wartością zaburzenia.

       Program sklada sie z 1 pliku w jezyku python
            1) Num8.py - program glowny
            2) raport.pdf
            3) data.txt - plik z danymi
           
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 Num8.py data.txt
  gdzie data.txt to nazwa pliku z danymi par współrzędnych (x, y).

========================================================================


