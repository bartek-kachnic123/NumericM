========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 09.11.2022
========================================================================

* Zawartosc:
============

Katalog NUM3 zawiera:
--------------------------------------------------------------------

I.     Program obliczający rozwiązania dla macierzy wstegowej A i jej wyznacznik
    za pomocą metody LU w czasie O(n).

       Program sklada sie z 1 pliku w jezyku python
            1) Num3.py - program glowny
            2) raport.pdf
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 num3.py N
   gdzie N = rozmiar macierzy ( domyślnie 100)
  

========================================================================


