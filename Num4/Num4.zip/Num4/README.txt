========================================================================
Autor: Bartłomiej Kachnic,                           Krakow, 16.11.2022
========================================================================

* Zawartosc:
============

Katalog NUM4 zawiera:
--------------------------------------------------------------------

I.     Program obliczający rozwiązania dla macierzy A, której szczegółowy opis
        znajduje się w raporcie. Program zapisuje w pliku *.csv czas w zależności
        od wielkości macierzy(od 1 do N)

       Program sklada sie z 1 pliku w jezyku python
            1) Num4.py - program glowny
            2) raport.pdf
            3) results.csv - plik z zmierzonym czasem obliczania rozwiązań
            

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

-> Aby uruchomic 1-szy program, nalezy wykonac komende:
   a)   python3 num4.py N
   gdzie N = rozmiar macierzy ( domyślnie 50)
  

========================================================================


